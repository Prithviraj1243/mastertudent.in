import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import session from "express-session";
import type { Express, RequestHandler } from "express";
import connectPg from "connect-pg-simple";
import { storage } from "./storage";
import { sendWelcomeEmail } from "./sendgrid";
import crypto from "crypto";

// Generate a simple password hash
function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password + 'salt_masterstudent').digest('hex');
}

// Verify password
function verifyPassword(password: string, hash: string): boolean {
  return hashPassword(password) === hash;
}

export function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: false,
    ttl: sessionTtl,
    tableName: "sessions",
  });
  return session({
    secret: process.env.SESSION_SECRET!,
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: sessionTtl,
    },
  });
}

async function createOrLoginUser(email: string, role?: string, firstName?: string, lastName?: string) {
  // Check if user exists
  let existingUser = await storage.getUserByEmail(email);
  
  if (!existingUser) {
    // Create new user with specified role
    const newUser = await storage.upsertUser({
      id: crypto.randomUUID(),
      email: email,
      firstName: firstName || email.split('@')[0],
      lastName: lastName || '',
      profileImageUrl: '',
      role: role === 'topper' ? 'topper' : 'student', // Default to student if not specified
    });
    
    // Send welcome email to new users
    try {
      await sendWelcomeEmail(email, firstName || email.split('@')[0]);
      console.log(`Welcome email sent to ${email}`);
    } catch (error) {
      console.error(`Failed to send welcome email to ${email}:`, error);
    }
    
    return newUser;
  }
  
  return existingUser;
}

export async function setupAuth(app: Express) {
  app.set("trust proxy", 1);
  app.use(getSession());
  app.use(passport.initialize());
  app.use(passport.session());

  // Simple email-based authentication strategy
  passport.use(new LocalStrategy(
    {
      usernameField: 'email',
      passwordField: 'email', // We'll use email as both username and password for simplicity
      passReqToCallback: true, // Allow access to req object
    },
    async (req: any, email: string, password: string, done) => {
      try {
        // For now, allow any valid email to login
        if (!email || !email.includes('@')) {
          return done(null, false, { message: 'Please enter a valid email address' });
        }
        
        // Get role from request body
        const role = req.body?.role;
        const user = await createOrLoginUser(email, role);
        return done(null, user);
      } catch (error) {
        return done(error);
      }
    }
  ));

  passport.serializeUser((user: any, cb) => {
    // Store the user ID in the session
    cb(null, user.id);
  });
  
  passport.deserializeUser(async (id: string, cb) => {
    try {
      const user = await storage.getUser(id);
      if (user) {
        cb(null, user);
      } else {
        cb(new Error('User not found'), null);
      }
    } catch (error) {
      console.error('Deserialization error:', error);
      cb(error, null);
    }
  });

  // Simple email login endpoint
  app.post("/api/login", (req, res, next) => {
    passport.authenticate('local', (err: any, user: any, info: any) => {
      if (err) {
        return res.status(500).json({ message: 'Authentication error' });
      }
      if (!user) {
        return res.status(400).json({ message: info?.message || 'Invalid email' });
      }
      
      req.logIn(user, (err) => {
        if (err) {
          return res.status(500).json({ message: 'Login error' });
        }
        return res.json({ success: true, user: { id: user.id, email: user.email, firstName: user.firstName } });
      });
    })(req, res, next);
  });

  // Simple logout endpoint
  app.post("/api/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: 'Logout error' });
      }
      res.json({ success: true });
    });
  });
}

export const isAuthenticated: RequestHandler = async (req, res, next) => {
  if (!req.isAuthenticated() || !req.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  return next();
};
